<table class="layui-table">
  <colgroup>
    <col width="150">
    <col>
    <col width="100">
    <col width="100">
  </colgroup>
  <thead>
    <tr>
      <th>属性名</th>
      <th>描述</th>
      <th>类型</th>
      <th>默认值</th>
    </tr> 
  </thead>
  <tbody>
    <tr>
<td>title</td>
<td>
  
数据标题

</td>
<td>string</td>
<td>-</td>
    </tr>
    <tr>
<td>value</td>
<td>
  
数据值

</td>
<td>string</td>
<td>-</td>
    </tr>
    <tr>
<td>checked</td>
<td>
  
是否选中状态

</td>
<td>boolean</td>
<td>

`false`

</td>
    </tr>
    <tr>
<td>disabled</td>
<td>
  
是否禁用状态

</td>
<td>boolean</td>
<td>

`false`

</td>
    </tr>
  </tbody>
</table>